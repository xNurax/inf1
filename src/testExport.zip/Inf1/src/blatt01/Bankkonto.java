package blatt01;

public class Bankkonto {
	public static void main(String[] args) {
		double guthabenInEuro = 0.0;
		System.out.println("Guthaben = " + guthabenInEuro);
		guthabenInEuro = guthabenInEuro + 100.0;
		System.out.println("Guthaben = " + guthabenInEuro);
		guthabenInEuro = guthabenInEuro - 50.0;
		System.out.println("Guthaben = " + guthabenInEuro);
	}

}
